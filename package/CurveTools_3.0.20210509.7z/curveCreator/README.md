# curveCreator

refactor of the original skinning tools
https://gumroad.com/l/WRtX

main goal of the tools is to make clean code that is ready for Python 3
maya code should be seperated in the Maya folder hopefully we can make some parts DCC agnostic to get the same or similar functionality in other dcc tools (future dev)

## Authors
* [Jan Pijpers](https://www.janpijpers.com/)
* [Perry Leijten](https://www.perryleijten.com/)

## Prerequisites

```
 - Maya 2017+
 - Python 2.7 (3.7)
```
